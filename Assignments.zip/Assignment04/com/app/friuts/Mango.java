package com.app.friuts;

public class Mango  extends Fruits{

    public Mango(String name, double weight, String color) {
        super(name, weight, color);
    }

    @Override
    public String taste() {
        return "sweet";
    }
}
