package com.app.friuts;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Fruits {
    private String color;
    private double weight;
    private String name;
    private boolean isFreash;
    private  String taste;

    // Getter
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    // Setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isFreash() {
        return isFreash;
    }

    public void setFreash(boolean freash) {
        isFreash = freash;
    }

    public String getTaste() {
        return taste;
    }

    public void setTaste(String taste) {
        this.taste = taste;
    }

    public Fruits(String name, double weight, String color){
        this.name = name;
        this.weight = weight;
        this.color = color;
        this.isFreash = true;
    }

    public Fruits() {
    }


    // toString
    @Override
    public String toString() {
        return "Fruit [name=" + name + ", color=" + color + ", weight=" + weight + ", isFresh=" + isFreash() + "]";
    }

    // taste method (polymorphic)
    public String taste() {
        return "no specific taste";
    }

    public int menu(Scanner sc){

        System.out.println("----------------------");
        System.out.println("0. EXIT");
        System.out.println("1. Add Mango");
        System.out.println("2. Add Orange");
        System.out.println("3. Add Apple");
        System.out.println("4. Display names of all fruits in the basket.");
        System.out.println("5. Display name, color, weight, taste of all fresh fruits, in the basket.");
        System.out.println("6. Display tastes of all stale(not fresh) fruits in the basket.");
        System.out.println("7. Mark a fruit as stale");
        System.out.println("8. Mark all sour fruits stale.");
        System.out.print("Enter your choice - ");

        try {
            return sc.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("exception");
            sc.nextInt();
            return 0;
        }


    }


    public void accept(String name,double weight, String color){
        Scanner sc = new Scanner(System.in);

            System.out.print("Enter name of fruit - ");
            this.name = sc.nextLine();

            System.out.print("Enter fruit color - ");
            this.color = sc.nextLine();

            System.out.print("Enter weight - ");
            this.weight = sc.nextDouble();




    }

    public int markAsStale(){
        Scanner sc = new Scanner(System.in);

        try{
            System.out.print("Enter index of fruit to stale - ");
            return sc.nextInt();
        }catch (InputMismatchException e){
            System.out.print("Exceptioncsdfs ");
            return 0;
        }

    }


}
