package com.app.friuts;

import java.util.InputMismatchException;
import java.util.Scanner;

public class FruitBasket {

    public static void main(String[] args) {
        Fruits f = new Fruits();

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Size of basket - ");

        int n = sc.nextInt();


        Fruits[] basket = new Fruits[n];

        int counter = 0;

        int choice;

        while((choice = f.menu(sc)) != 0){

            try {
                switch (choice){
                    case 1:
                        if (counter < basket.length) {
                            f.accept(f.getName(), f.getWeight(), f.getColor());
                            basket[counter++] = new Mango(f.getName(), f.getWeight(), f.getColor());
                            System.out.println("-------- MANGO ADDED SUCCESSFULLY ------");
                        } else {
                            System.out.println("Basket full!");
                        }
                        break;
                    case 2:
                        if (counter < basket.length) {
                            f.accept(f.getName(), f.getWeight(), f.getColor());
                            basket[counter++] = new Orange(f.getName(), f.getWeight(), f.getColor());
                            System.out.println("-------- ORANGE ADDED SUCCESSFULLY ------");
                        } else {
                            System.out.println("Basket full!");
                        }
                        break;

                    case 3:
                        if (counter < basket.length) {
                            f.accept(f.getName(), f.getWeight(), f.getColor());
                            basket[counter++] = new Apple(f.getName(), f.getWeight(), f.getColor());
                            System.out.println("-------- APPLE ADDED SUCCESSFULLY ------");
                        } else {
                            System.out.println("Basket full!");
                        }
                        break;

                    case 4:
                        if(basket [0] != null) {
                            System.out.println("Fruits in basket:");
                            for (Fruits fruit : basket)
                                System.out.println(fruit);
                        } else {
                            System.out.println("No fruit available in the basket...");
                        }
                        break;

                    case 5:
                        if(basket [0] != null) {
                            System.out.println("Fresh fruits details:");
                            for (Fruits ff : basket) {
                                if (ff != null && ff.isFreash()) {
                                    System.out.println(ff.toString() + ", taste=" + ff.taste());
                                }
                            }
                        }else {
                            System.out.println("No fresh fruit available...");
                        }
                        break;

                    case 6:
                        if(basket [0] != null) {
                            // Display tastes of all stale(not fresh) fruits in the basket.
                            if (!f.isFreash()) {
                                for (Fruits fruit : basket)
                                    System.out.println(fruit);
                            } else {
                                System.out.println("No stale fruit available...");
                            }
                        }
                        else {
                            System.out.println("No fruit available...");
                        }
                        break;

                    case 7:
                        if(basket [0] != null) {
                            //mark fruit as stale as the index of fruit.
                            int staleFruit = f.markAsStale();
                            basket[staleFruit].setFreash(false);
                            System.out.println("-------- FRUIT STALE SUCCESSFULLY ------");
                        }
                        else {
                            System.out.println("No fruit available...");
                        }
                        break;

                    case 8:
                        if(basket [0] != null) {
                            // mark all sour fruit as stale...
                            for(int i = 0; i < basket.length; i++) {
                                if(basket[i].getTaste().contains("sour"))
                                    basket[i].setFreash(false);
                                else
                                    System.out.println("There is no sure fruit available.");
                            }
                            System.out.println("-------- FRUIT STALE SUCCESSFULLY ------");
                        }
                        else {
                            System.out.println("No fruit available...");
                        }
                        break;

                    default:
                        System.out.println("wrong option");
                        break;
                }
            }catch (InputMismatchException e){
                System.out.println("You gave a wronge input, Please check and give the input again!");
                sc.nextLine();
            }


        }
    }
}
